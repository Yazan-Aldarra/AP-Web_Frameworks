import { Component } from '@angular/core';

@Component({
  selector: 'app-component1',
  imports: [],
  templateUrl: './component1.html',
  styleUrl: './component1.css',
})
export class Component1 {
  naam = 'Angular beginner';
  aantal = 3;
}
