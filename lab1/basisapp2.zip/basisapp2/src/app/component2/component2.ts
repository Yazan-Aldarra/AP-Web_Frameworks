import { Component } from '@angular/core';

@Component({
  selector: 'app-component2',
  imports: [],
  templateUrl: './component2.html',
  styleUrl: './component2.css',
})
export class Component2 {
  afbeeldingUrl = 'https://angular.dev/assets/images/ng-image.jpg';
  breedte = 80;
}
