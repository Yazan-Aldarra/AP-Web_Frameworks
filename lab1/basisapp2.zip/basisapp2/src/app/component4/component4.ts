import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-component4',
  imports: [FormsModule],
  templateUrl: './component4.html',
  styleUrl: './component4.css',
})
export class Component4 {
  gebruiker = '';
}
